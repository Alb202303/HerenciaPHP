<?php
require_once ('./padre/animal.php');
class gato extends animal {

    public function comer(){
        echo "<p>Gato comiendo</p>";
    }

    public function protectedPadre(){
        $this->dormir();
    }
}

?>