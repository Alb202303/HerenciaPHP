<?php
require_once ('./padre/animal.php');
class perro extends animal {

    public function comer(){
        echo "<p>Perro comiendo huesos</p>";
    }

    public function protectedPadre(){
        $this->dormir();
    }
}

?>